package user.service;

public class UserServiceImpl implements UserService {

}
