package user.service;

public interface UserService {

}
