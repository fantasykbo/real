package user.dao;

public class UserDAOImpl implements UserDAO {

}
