package user.dao;

public interface UserDAO {

}
