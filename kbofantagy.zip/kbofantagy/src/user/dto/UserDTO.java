package user.dto;

public class UserDTO {
	
}
