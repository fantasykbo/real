package fw;

public class Query {

}
