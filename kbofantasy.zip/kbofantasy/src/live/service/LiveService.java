package live.service;

public interface LiveService {
	String printlivetext(String eventId, String month);
}
