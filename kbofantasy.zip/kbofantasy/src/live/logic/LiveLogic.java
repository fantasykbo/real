package live.logic;

public interface LiveLogic {
	String printlivetext(String eventId, String month);
	
}
