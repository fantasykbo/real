package game.service;

import java.util.ArrayList;

public interface RankingService {
	ArrayList<String[]> getUser();
	ArrayList<String[]> get_b_player();
	ArrayList<String[]> get_p_player();
}
	